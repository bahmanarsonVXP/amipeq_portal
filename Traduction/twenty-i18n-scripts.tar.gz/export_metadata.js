#!/usr/bin/env node
/**
 * Twenty CRM — Export des métadonnées (objets + champs) vers Excel
 * 
 * Usage:
 *   node export_metadata.js <TWENTY_URL> <API_KEY>
 * 
 * Exemple:
 *   node export_metadata.js https://twenty-production-0500.up.railway.app "eyJhbG..."
 * 
 * Génère: twenty_metadata_fr.xlsx
 */

const https = require('https');
const http = require('http');

const TWENTY_URL = process.argv[2];
const API_KEY = process.argv[3];

if (!TWENTY_URL || !API_KEY) {
  console.error('Usage: node export_metadata.js <TWENTY_URL> <API_KEY>');
  process.exit(1);
}

const BASE_URL = TWENTY_URL.replace(/\/$/, '');

// --- Traductions françaises pré-remplies pour les objets/champs standard ---
const OBJECT_TRANSLATIONS = {
  'person': 'Contact',
  'people': 'Contacts',
  'company': 'Entreprise',
  'companies': 'Entreprises',
  'opportunity': 'Opportunité',
  'opportunities': 'Opportunités',
  'note': 'Note',
  'notes': 'Notes',
  'task': 'Tâche',
  'tasks': 'Tâches',
  'noteTarget': 'Cible de note',
  'taskTarget': 'Cible de tâche',
  'attachment': 'Pièce jointe',
  'favorite': 'Favori',
  'view': 'Vue',
  'viewField': 'Champ de vue',
  'viewFilter': 'Filtre de vue',
  'viewSort': 'Tri de vue',
  'webhook': 'Webhook',
  'workspaceMember': 'Membre',
  'message': 'Message',
  'messageChannel': 'Canal de messages',
  'messageParticipant': 'Participant au message',
  'messageThread': 'Fil de discussion',
  'calendarEvent': 'Événement',
  'calendarEventParticipant': 'Participant',
  'blocklist': 'Liste de blocage',
  'connectedAccount': 'Compte connecté',
  'audit': 'Audit',
  'workflow': 'Workflow',
  'workflowVersion': 'Version de workflow',
  'workflowRun': 'Exécution de workflow',
};

const FIELD_TRANSLATIONS = {
  'name': 'Nom',
  'firstName': 'Prénom',
  'lastName': 'Nom de famille',
  'email': 'E-mail',
  'emails': 'E-mails',
  'phone': 'Téléphone',
  'phones': 'Téléphones',
  'city': 'Ville',
  'address': 'Adresse',
  'jobTitle': 'Fonction',
  'linkedinLink': 'LinkedIn',
  'xLink': 'X (Twitter)',
  'avatarUrl': 'Avatar',
  'position': 'Position',
  'createdBy': 'Créé par',
  'createdAt': 'Date de création',
  'updatedAt': 'Date de modification',
  'deletedAt': 'Date de suppression',
  'domainName': 'Nom de domaine',
  'employees': 'Effectifs',
  'idealCustomerProfile': 'Profil client idéal',
  'annualRecurringRevenue': 'Revenu annuel récurrent',
  'visaSponsorship': 'Sponsoring visa',
  'accountOwner': 'Responsable du compte',
  'stage': 'Étape',
  'amount': 'Montant',
  'closeDate': 'Date de clôture',
  'probability': 'Probabilité',
  'pointOfContact': 'Point de contact',
  'company': 'Entreprise',
  'people': 'Contacts',
  'person': 'Contact',
  'title': 'Titre',
  'body': 'Contenu',
  'status': 'Statut',
  'dueAt': 'Échéance',
  'assignee': 'Assigné à',
  'description': 'Description',
  'type': 'Type',
  'currency': 'Devise',
  'intro': 'Introduction',
  'tagline': 'Slogan',
  'workPolicy': 'Politique de travail',
  'searchVector': 'Vecteur de recherche',
};

function fetchJSON(url, token) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const lib = parsedUrl.protocol === 'https:' ? https : http;
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port,
      path: parsedUrl.pathname + parsedUrl.search,
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    };

    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Failed to parse response: ${data.substring(0, 200)}`));
        }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

function postGraphQL(url, token, query, variables = {}) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const lib = parsedUrl.protocol === 'https:' ? https : http;
    const body = JSON.stringify({ query, variables });

    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port,
      path: '/metadata',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
      }
    };

    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Failed to parse response: ${data.substring(0, 500)}`));
        }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function main() {
  console.log('🔍 Récupération des métadonnées depuis', BASE_URL, '...\n');

  // Try GraphQL metadata endpoint first
  const query = `
    query {
      objects(paging: { first: 100 }) {
        edges {
          node {
            id
            nameSingular
            namePlural
            labelSingular
            labelPlural
            description
            isCustom
            isActive
            fields(paging: { first: 200 }) {
              edges {
                node {
                  id
                  name
                  label
                  description
                  type
                  isCustom
                  isActive
                  isSystem
                }
              }
            }
          }
        }
      }
    }
  `;

  let objects;
  try {
    const result = await postGraphQL(BASE_URL, API_KEY, query);
    if (result.errors) {
      console.error('GraphQL errors:', JSON.stringify(result.errors, null, 2));
      process.exit(1);
    }
    objects = result.data.objects.edges.map(e => e.node);
  } catch (err) {
    console.error('Error fetching metadata:', err.message);
    console.log('\nTrying REST endpoint...');
    try {
      const restResult = await fetchJSON(`${BASE_URL}/rest/metadata/objects`, API_KEY);
      objects = restResult.data?.objects || restResult;
    } catch (err2) {
      console.error('REST also failed:', err2.message);
      process.exit(1);
    }
  }

  console.log(`✅ ${objects.length} objets récupérés\n`);

  // Build CSV data (tab-separated for easy Excel import)
  const rows = [];
  
  // Header
  rows.push([
    'Type',
    'Objet ID',
    'Champ ID', 
    'Nom technique',
    'Label actuel (EN)',
    'Label FR (à modifier)',
    'Description',
    'Type de champ',
    'Custom?',
    'Actif?',
    'Système?'
  ].join('\t'));

  // Sort: active non-system objects first
  const sortedObjects = objects
    .filter(o => o.isActive)
    .sort((a, b) => {
      if (a.isCustom !== b.isCustom) return a.isCustom ? 1 : -1;
      return (a.labelSingular || a.nameSingular).localeCompare(b.labelSingular || b.nameSingular);
    });

  for (const obj of sortedObjects) {
    const objName = obj.nameSingular || obj.namePlural;
    const objLabel = obj.labelSingular || objName;
    const objLabelPlural = obj.labelPlural || obj.namePlural || '';
    
    // Suggest French translation
    const frSingular = OBJECT_TRANSLATIONS[obj.nameSingular] || OBJECT_TRANSLATIONS[objName.toLowerCase()] || '';
    const frPlural = OBJECT_TRANSLATIONS[obj.namePlural] || OBJECT_TRANSLATIONS[(obj.namePlural || '').toLowerCase()] || '';
    const frLabel = frSingular ? `${frSingular} / ${frPlural}` : '';

    // Object row
    rows.push([
      'OBJET',
      obj.id,
      '',
      `${obj.nameSingular} / ${obj.namePlural}`,
      `${objLabel} / ${objLabelPlural}`,
      frLabel,
      obj.description || '',
      '',
      obj.isCustom ? 'Oui' : 'Non',
      obj.isActive ? 'Oui' : 'Non',
      ''
    ].join('\t'));

    // Fields
    const fields = (obj.fields?.edges || [])
      .map(e => e.node)
      .filter(f => f.isActive)
      .sort((a, b) => {
        if (a.isSystem !== b.isSystem) return a.isSystem ? 1 : -1;
        if (a.isCustom !== b.isCustom) return a.isCustom ? 1 : -1;
        return (a.label || a.name).localeCompare(b.label || b.name);
      });

    for (const field of fields) {
      const fieldName = field.name;
      const fieldLabel = field.label || fieldName;
      const frField = FIELD_TRANSLATIONS[fieldName] || FIELD_TRANSLATIONS[fieldName.toLowerCase()] || '';

      rows.push([
        '  champ',
        obj.id,
        field.id,
        fieldName,
        fieldLabel,
        frField,
        field.description || '',
        field.type || '',
        field.isCustom ? 'Oui' : 'Non',
        field.isActive ? 'Oui' : 'Non',
        field.isSystem ? 'Oui' : 'Non'
      ].join('\t'));
    }
  }

  // Write TSV file
  const fs = require('fs');
  const tsvContent = rows.join('\n');
  fs.writeFileSync('twenty_metadata_fr.tsv', tsvContent, 'utf-8');
  
  console.log(`📄 Fichier généré: twenty_metadata_fr.tsv`);
  console.log(`   ${rows.length - 1} lignes (objets + champs)`);
  console.log(`\n📋 Instructions:`);
  console.log(`   1. Ouvre twenty_metadata_fr.tsv dans Excel`);
  console.log(`   2. Modifie la colonne F "Label FR (à modifier)"`);
  console.log(`   3. Sauvegarde en .tsv (séparateur tabulation)`);
  console.log(`   4. Lance: node import_translations.js <TWENTY_URL> <API_KEY> twenty_metadata_fr.tsv`);
  
  // Also output JSON for the import script
  const metadata = sortedObjects.map(obj => ({
    id: obj.id,
    nameSingular: obj.nameSingular,
    namePlural: obj.namePlural,
    labelSingular: obj.labelSingular,
    labelPlural: obj.labelPlural,
    isCustom: obj.isCustom,
    fields: (obj.fields?.edges || []).map(e => ({
      id: e.node.id,
      name: e.node.name,
      label: e.node.label,
      type: e.node.type,
      isCustom: e.node.isCustom,
      isSystem: e.node.isSystem,
    }))
  }));
  
  fs.writeFileSync('twenty_metadata_backup.json', JSON.stringify(metadata, null, 2), 'utf-8');
  console.log(`\n💾 Backup JSON sauvegardé: twenty_metadata_backup.json`);
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
